# Employee REST API - Task 13

Spring Boot RESTful application with Bean Validation and Global Exception Handling.

## Prerequisites
- JDK 17
- Spring Tools Suite 5.0.1
- SQL Server Express (SQLEXPRESS)
- SSMS
- Postman

## Setup Steps

### 1. Database Setup
Open SSMS and run the contents of `sql-setup.sql`.
Update the password as needed.

### 2. Configure Database Connection
Edit `src/main/resources/application.properties`:
```
spring.datasource.username=studentuser
spring.datasource.password=yourpassword
```

### 3. Run the Application
In STS: Right-click project → Run As → Spring Boot App
Server starts at: http://localhost:8080

## API Endpoints

| Method | URL                        | Description        |
|--------|----------------------------|--------------------|
| POST   | /api/employees             | Add employee       |
| GET    | /api/employees             | Get all employees  |
| GET    | /api/employees/{id}        | Get employee by ID |
| PUT    | /api/employees/{id}        | Update employee    |
| DELETE | /api/employees/{id}        | Delete employee    |

## Postman Test Bodies

### Add Employee (POST)
```json
{
  "name": "John",
  "email": "john@gmail.com",
  "salary": 50000,
  "department": "IT"
}
```

### Validation Error Test (POST - invalid data)
```json
{
  "name": "",
  "email": "invalid",
  "salary": -5000,
  "department": ""
}
```

### Not Found Test
GET http://localhost:8080/api/employees/99

## Expected Error Responses

### Validation Error (400)
```json
{
  "name": "Name is mandatory",
  "email": "Invalid email format",
  "salary": "Salary must be greater than 0",
  "department": "Department is mandatory"
}
```

### Not Found (404)
```json
{
  "timestamp": "2026-03-22T10:00:00",
  "status": 404,
  "error": "Not Found",
  "message": "Employee not found with id: 99"
}
```
