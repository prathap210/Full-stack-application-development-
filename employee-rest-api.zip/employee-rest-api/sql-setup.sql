-- Run this in SQL Server Management Studio (SSMS)

-- Step 1: Create the database
CREATE DATABASE employee;
GO

-- Step 2: Create the table
USE employee;
CREATE TABLE employees (
    id         BIGINT IDENTITY(1,1) PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    email      VARCHAR(150)  UNIQUE NOT NULL,
    salary     DECIMAL(10,2) NOT NULL,
    department VARCHAR(100)  NOT NULL
);
GO

-- Step 3: Create login and user
CREATE LOGIN studentuser WITH PASSWORD = 'yourpassword';
GO

USE employee;
CREATE USER studentuser FOR LOGIN studentuser;
ALTER ROLE db_owner ADD MEMBER studentuser;
GO

-- Step 4: Verify setup
SELECT name FROM sys.databases WHERE name = 'employee';
SELECT * FROM employees;
